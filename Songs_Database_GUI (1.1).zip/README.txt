To enter the app, you need to create an account, the date of birth can be any date which can be used to reset the password of the user.
After logging in, you are able to insert items manually into the remote database. The database is being hosted by heroku, as such, wifi
is needed for it to work. Other than adding items, you can select and delete items or delete all items in a table.
Other features such as display and update have all their queries already made, but due to not being able to finish those parts of the app,
they do not work currently.
JRE is needed for the app to work.
Launch4j was used to compile th maven jar file into an exe file.
The report images are a bit outdates on small matters we changed in the last week.